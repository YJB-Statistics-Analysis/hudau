from setuptools import setup, find_packages
setup(name = "hudau",
      version = 0.1,
      description="Package containing functions commonly used by the YJB Statistics and Analysis Team",
      author="AI_ynnna",
      author_email="adela.iliescu@yjb.gov.uk",
      packages=find_packages()
      )